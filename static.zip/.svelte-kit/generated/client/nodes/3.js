import * as universal from "../../../../src/routes/gallery/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/gallery/+page.svelte";