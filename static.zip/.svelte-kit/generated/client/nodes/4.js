import * as universal from "../../../../src/routes/projects/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/projects/+page.svelte";