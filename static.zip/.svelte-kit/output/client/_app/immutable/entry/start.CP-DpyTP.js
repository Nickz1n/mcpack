import{a as t}from"../chunks/D3J4r5ii.js";export{t as start};
