import{D as o}from"./UNozRNFT.js";const s=o;export{s as d};
