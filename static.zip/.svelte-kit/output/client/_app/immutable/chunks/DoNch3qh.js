import{o as a}from"./UNozRNFT.js";a();
