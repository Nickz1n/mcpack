

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.D_-EZOcm.js","_app/immutable/chunks/BArY2uKR.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/DoNch3qh.js","_app/immutable/chunks/BxGGIijJ.js","_app/immutable/chunks/B05Z61Y6.js","_app/immutable/chunks/D3J4r5ii.js","_app/immutable/chunks/CnT20KpT.js"];
export const stylesheets = ["_app/immutable/assets/0.CnOllnkX.css"];
export const fonts = ["_app/immutable/assets/bebas_neue.CLoul1ni.woff2","_app/immutable/assets/outfit.B-fmKU8E.woff2"];
