import * as universal from '../entries/pages/projects/_page.js';

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/projects/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/projects/+page.js";
export const imports = ["_app/immutable/nodes/4.BPB5quAB.js","_app/immutable/chunks/BS25xd2y.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/BArY2uKR.js","_app/immutable/chunks/DoNch3qh.js","_app/immutable/chunks/Dv-_pHmK.js"];
export const stylesheets = [];
export const fonts = [];
