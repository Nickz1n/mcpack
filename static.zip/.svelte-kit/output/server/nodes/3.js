import * as universal from '../entries/pages/gallery/_page.js';

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/gallery/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/gallery/+page.js";
export const imports = ["_app/immutable/nodes/3.BPB5quAB.js","_app/immutable/chunks/BS25xd2y.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/BArY2uKR.js","_app/immutable/chunks/DoNch3qh.js","_app/immutable/chunks/Dv-_pHmK.js"];
export const stylesheets = [];
export const fonts = [];
