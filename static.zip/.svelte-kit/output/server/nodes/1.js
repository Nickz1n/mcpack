

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.V2IO4etI.js","_app/immutable/chunks/BArY2uKR.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/DoNch3qh.js","_app/immutable/chunks/D61cHcN7.js","_app/immutable/chunks/Dv-_pHmK.js","_app/immutable/chunks/B05Z61Y6.js","_app/immutable/chunks/D3J4r5ii.js","_app/immutable/chunks/CnT20KpT.js"];
export const stylesheets = [];
export const fonts = [];
