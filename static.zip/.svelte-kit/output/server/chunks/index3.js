import { B as BROWSER } from "./false.js";
const dev = BROWSER;
export {
  dev as d
};
