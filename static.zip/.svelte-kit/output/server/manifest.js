export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","js/carousel.js","robots.txt"]),
	mimeTypes: {".png":"image/png",".js":"text/javascript",".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.CP-DpyTP.js",app:"_app/immutable/entry/app.DqRNI6Ee.js",imports:["_app/immutable/entry/start.CP-DpyTP.js","_app/immutable/chunks/D3J4r5ii.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/CnT20KpT.js","_app/immutable/entry/app.DqRNI6Ee.js","_app/immutable/chunks/UNozRNFT.js","_app/immutable/chunks/D61cHcN7.js","_app/immutable/chunks/Dv-_pHmK.js","_app/immutable/chunks/BArY2uKR.js","_app/immutable/chunks/CnT20KpT.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			
		],
		routes: [
			
		],
		prerendered_routes: new Set(["/","/gallery","/projects"]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
